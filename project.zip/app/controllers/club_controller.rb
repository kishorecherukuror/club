class ClubController < ApplicationController
 
  def coffee
  end
  def wine
  end
  def beer
  end
  def cigars
  end
  def games
  end
  def flowers
  end

end
